﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseACodigo
{
    public class FacturaLuz : Impuesto
    {
        public String CodigoPago { get; set; }
        //public double Importe { get; set; }
    }
}
