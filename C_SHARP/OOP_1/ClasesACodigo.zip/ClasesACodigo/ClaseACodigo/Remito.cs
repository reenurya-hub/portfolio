﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseACodigo
{
    public class Remito //: DocumentoContable
    {
        public int CantidadBultos { get; set; }
        public DateTime Fecha { get; set; }

        public int Numero { get; set; }

    }
}
