﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseACodigo
{
    public class ReciboSueldo
    {
        public int Legajo { get; set; }
        public double Total { get; set; }
    }
}
