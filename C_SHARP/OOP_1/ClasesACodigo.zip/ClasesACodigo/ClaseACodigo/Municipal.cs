﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseACodigo
{
    public class Municipal : Impuesto
    {
        //public double Importe { get; set; }
        public string Partida { get; set; }
    }
}
