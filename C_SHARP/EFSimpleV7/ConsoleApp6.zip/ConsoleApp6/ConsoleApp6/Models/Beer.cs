﻿using System;
using System.Collections.Generic;

namespace ConsoleApp6.Models;

public partial class Beer
{
    public int BeerId { get; set; }

    public string? Name { get; set; }

    public string? Style { get; set; }
}
