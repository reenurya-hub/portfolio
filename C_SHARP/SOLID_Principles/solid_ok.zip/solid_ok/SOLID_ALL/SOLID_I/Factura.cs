﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_I
{
    public class Factura : Documento
    {
        public Factura(int numero, DateTime fecha) : base (numero, fecha) 
        { 

        }

        public string CAI { get; set; }
        /*
        public override void EnviarPorEmail()
        {
            //esta operacion no es valida para factura
        }
        */

        
        public override void Imprimir()
        {
            Console.WriteLine($"Imprimiendo por email la factura {Numero} del dia {Fecha.ToShortDateString()}");
        }
    }
}
