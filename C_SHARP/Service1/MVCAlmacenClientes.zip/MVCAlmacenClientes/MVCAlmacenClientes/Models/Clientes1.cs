﻿using System;
using System.Collections.Generic;

namespace MVCAlmacenClientes.Models;

public partial class Clientes1
{
    public string? CliId { get; set; }

    public string? CliNom { get; set; }
}
