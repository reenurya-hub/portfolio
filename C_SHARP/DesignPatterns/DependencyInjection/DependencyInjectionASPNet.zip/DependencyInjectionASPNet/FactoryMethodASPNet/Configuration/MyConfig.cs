﻿namespace FactoryMethodASPNet.Configuration
{
    public class MyConfig
    {
        public string PathLog { get; set; }
    }
}
