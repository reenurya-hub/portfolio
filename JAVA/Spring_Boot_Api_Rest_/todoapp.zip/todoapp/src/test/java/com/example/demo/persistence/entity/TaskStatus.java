package com.example.demo.persistence.entity;

public enum TaskStatus {
	ON_TIME, LATE
}
